"""Модели SQLite и тела запросов для магазина велосипедов."""
from datetime import date
from sqlmodel import Field, SQLModel


class Product(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)
    name: str
    price: int = Field(ge=0)
    image: str | None = None
    description: str | None = None
    rent_per_day: int = Field(default=500, ge=0)
    status: str = 'available'


class ProductCreate(SQLModel):
    name: str
    price: int = Field(ge=0)
    image: str | None = None
    description: str | None = None
    rent_per_day: int = Field(default=500, ge=0)


class Customer(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)
    name: str
    phone: str


class Order(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)
    product_id: int = Field(foreign_key='product.id')
    customer_id: int = Field(foreign_key='customer.id')
    kind: str
    start_date: date
    due_date: date | None = None
    returned_date: date | None = None
    amount: int = Field(ge=0)


class Checkout(SQLModel):
    name: str
    phone: str
    days: int = 1
