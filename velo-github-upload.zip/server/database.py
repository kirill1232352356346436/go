"""Подключение к базе, сохранение старого каталога и начальные данные."""
from pathlib import Path
from sqlmodel import Session, SQLModel, create_engine, select
from catalog_seed import SEED
from models import Product, Customer, Order  # register all tables before create_all

DATABASE = Path(__file__).with_name('store.db')
engine = create_engine(f'sqlite:///{DATABASE}', connect_args={'check_same_thread': False})


def initialize_database():
    SQLModel.metadata.create_all(engine)
    with engine.begin() as conn:
        cols = {row[1] for row in conn.exec_driver_sql('PRAGMA table_info(product)')}
        if 'rent_per_day' not in cols:
            conn.exec_driver_sql('ALTER TABLE product ADD COLUMN rent_per_day INTEGER NOT NULL DEFAULT 500')
        if 'status' not in cols:
            conn.exec_driver_sql("ALTER TABLE product ADD COLUMN status TEXT NOT NULL DEFAULT 'available'")
    with Session(engine) as session:
        if session.exec(select(Product)).first() is None:
            session.add_all(Product(**item) for item in SEED)
            session.commit()
