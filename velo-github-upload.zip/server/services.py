"""Бизнес-правила продажи, аренды и возврата."""
from datetime import date, timedelta
from fastapi import HTTPException
from sqlmodel import Session
from database import engine
from models import Checkout, Customer, Order, Product


def transaction(action):
    # SQLite блокирует параллельные записи до проверки доступности велосипеда.
    with engine.connect() as conn:
        conn.exec_driver_sql('BEGIN IMMEDIATE')
        try:
            with Session(bind=conn) as session:
                result = action(session)
                session.flush()
            conn.commit()
            return result
        except Exception:
            conn.rollback()
            raise


def place_order(product_id: int, kind: str, data: Checkout):
    if not data.name.strip() or not data.phone.strip() or (kind == 'rent' and data.days < 1):
        raise HTTPException(422, 'Укажите имя, телефон и положительное число дней аренды')

    def save(session):
        bike = session.get(Product, product_id)
        if bike is None:
            raise HTTPException(404, 'Велосипед не найден')
        if bike.status != 'available':
            raise HTTPException(409, 'Велосипед сейчас недоступен')
        customer = Customer(name=data.name.strip(), phone=data.phone.strip())
        session.add(customer)
        session.flush()
        order = Order(product_id=product_id, customer_id=customer.id, kind=kind,
                      start_date=date.today(),
                      due_date=date.today() + timedelta(days=data.days) if kind == 'rent' else None,
                      amount=bike.rent_per_day * data.days if kind == 'rent' else bike.price)
        session.add(order)
        bike.status = 'rented' if kind == 'rent' else 'sold'
        session.flush()
        return {'id': order.id, 'kind': kind, 'amount': order.amount,
                'due_date': order.due_date.isoformat() if order.due_date else None}

    return transaction(save)


def complete_rental(order_id: int):
    def save(session):
        order = session.get(Order, order_id)
        if order is None:
            raise HTTPException(404, 'Заказ не найден')
        if order.kind != 'rent' or order.returned_date is not None:
            raise HTTPException(409, 'Эта аренда уже завершена или заказ является продажей')
        bike = session.get(Product, order.product_id)
        order.returned_date = date.today()
        bike.status = 'available'
        session.flush()
        return Order.model_validate(order.model_dump())

    return transaction(save)
