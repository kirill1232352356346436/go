"""HTTP API магазина велосипедов. Запуск: uvicorn main:app --port 8010."""
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException
from sqlmodel import Session, select
from database import engine, initialize_database
from models import Checkout, Order, Product, ProductCreate
from services import complete_rental, place_order


@asynccontextmanager
async def lifespan(app: FastAPI):
    initialize_database()
    yield


app = FastAPI(title='Веломагазин — продажа и прокат', version='2.0', lifespan=lifespan)


@app.get('/products', response_model=list[Product], tags=['Каталог'])
def products():
    with Session(engine) as session:
        return list(session.exec(select(Product).order_by(Product.id)))


@app.get('/products/{product_id}', response_model=Product, tags=['Каталог'])
def product(product_id: int):
    with Session(engine) as session:
        bike = session.get(Product, product_id)
        if bike is None:
            raise HTTPException(404, 'Велосипед не найден')
        return bike


@app.post('/products', response_model=Product, status_code=201, tags=['Каталог'])
def add_product(data: ProductCreate):
    if not data.name.strip():
        raise HTTPException(422, 'Укажите название')
    with Session(engine) as session:
        bike = Product(**(data.model_dump() | {'name': data.name.strip()}))
        session.add(bike)
        session.commit()
        session.refresh(bike)
        return bike


@app.put('/products/{product_id}', response_model=Product, tags=['Каталог'])
def edit_product(product_id: int, data: ProductCreate):
    if not data.name.strip():
        raise HTTPException(422, 'Укажите название')
    with Session(engine) as session:
        bike = session.get(Product, product_id)
        if bike is None:
            raise HTTPException(404, 'Велосипед не найден')
        for key, value in data.model_dump().items():
            setattr(bike, key, value)
        session.add(bike)
        session.commit()
        session.refresh(bike)
        return bike


@app.delete('/products/{product_id}', status_code=204, tags=['Каталог'])
def remove_product(product_id: int):
    with Session(engine) as session:
        bike = session.get(Product, product_id)
        if bike is None:
            raise HTTPException(404, 'Велосипед не найден')
        if session.exec(select(Order).where(Order.product_id == product_id)).first():
            raise HTTPException(409, 'У велосипеда есть история заказов')
        session.delete(bike)
        session.commit()


@app.post('/products/{product_id}/sale', status_code=201, tags=['Заказы'])
def sell(product_id: int, data: Checkout):
    return place_order(product_id, 'sale', data)


@app.post('/products/{product_id}/rent', status_code=201, tags=['Заказы'])
def rent(product_id: int, data: Checkout):
    return place_order(product_id, 'rent', data)


@app.get('/orders', response_model=list[Order], tags=['Заказы'])
def orders():
    with Session(engine) as session:
        return list(session.exec(select(Order).order_by(Order.id.desc())))


@app.post('/orders/{order_id}/return', response_model=Order, tags=['Заказы'])
def return_bike(order_id: int):
    return complete_rental(order_id)
