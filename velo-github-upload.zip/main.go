package main

import (
	"fmt"
	_ "time"

	gui "github.com/kirill1232352356346436/go/GUI"
	backend "github.com/kirill1232352356346436/go/backend"
)

func main() {
	fmt.Println("Start!")
	go backend.Start_backend()
	if !gui.Start_gui() {
		fmt.Println("GUI failed initialize!")
	}
}
