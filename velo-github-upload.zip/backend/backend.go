package backend

import (
	"bytes"
	"encoding/json"
	"fmt"
	"errors"
	"net/http"
	"time"

	Config "github.com/kirill1232352356346436/go/config"
	"github.com/kirill1232352356346436/go/events"
)

const apiBase = "http://127.0.0.1:8010"

type product struct {
	ID          int    `json:"id"`
	Name        string `json:"name"`
	Price       int    `json:"price"`
	Image       string `json:"image"`
	Description string `json:"description"`
	RentPerDay int `json:"rent_per_day"`
	Status string `json:"status"`
}

type Order struct {
	ID int `json:"id"`
	ProductID int `json:"product_id"`
	Kind string `json:"kind"`
	Amount int `json:"amount"`
	DueDate string `json:"due_date"`
	ReturnedDate *string `json:"returned_date"`
}

var httpClient = &http.Client{Timeout: 5 * time.Second}

func request(method, path string, input any, output any) error {
	var body bytes.Buffer
	if input != nil {
		if err := json.NewEncoder(&body).Encode(input); err != nil { return err }
	}
	req, err := http.NewRequest(method, apiBase+path, &body)
	if err != nil { return err }
	if input != nil { req.Header.Set("Content-Type", "application/json") }
	resp, err := httpClient.Do(req)
	if err != nil { return err }
	defer resp.Body.Close()
	if resp.StatusCode >= 300 { return errors.New(resp.Status) }
	if output != nil { return json.NewDecoder(resp.Body).Decode(output) }
	return nil
}

func Checkout(id int, kind, name, phone string, days int) (Order, error) {
	var result Order
	err := request("POST", fmt.Sprintf("/products/%d/%s", id, kind),
		map[string]any{"name": name, "phone": phone, "days": days}, &result)
	return result, err
}

func Orders() ([]Order, error) {
	var result []Order
	err := request("GET", "/orders", nil, &result)
	return result, err
}

func ReturnOrder(id int) error {
	return request("POST", fmt.Sprintf("/orders/%d/return", id), nil, nil)
}

func Start_backend() bool {
	fmt.Println("Backend initialize! Client -> " + apiBase)

	client := &http.Client{Timeout: 5 * time.Second}

	for req := range events.Request {
		switch req.Type {
		case "GET_CATALOG":
			catalog, err := getCatalog(client)
			if err != nil {
				fmt.Println("GET_CATALOG error:", err)
				continue
			}
			events.Result <- catalog
		}
	}

	return true
}

func getCatalog(client *http.Client) ([]Config.Buycard, error) {
	resp, err := client.Get(apiBase + "/products")
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	var items []product
	if err := json.NewDecoder(resp.Body).Decode(&items); err != nil {
		return nil, err
	}

	catalog := make([]Config.Buycard, 0, len(items))
	for _, p := range items {
		catalog = append(catalog, Config.Buycard{
			ID: p.ID,
			Name:  p.Name,
			Price: p.Price,
			RentPerDay: p.RentPerDay,
			Status: p.Status,
			SizeX: 200,
			SizeY: 200,
		})
	}
	return catalog, nil
}
